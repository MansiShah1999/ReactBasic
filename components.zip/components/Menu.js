import React,{Component} from 'react'

class Menu extends Component{

}
export default Menu
