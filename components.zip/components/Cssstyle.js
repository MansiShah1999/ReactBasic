import React from 'react'
import './style.css'

function Cssstyle(props){
    let className=props.className ? 'primary':''
    return(
    <div>
        <h1 className={`${className} font-xl`}>Stylesheet</h1>
    </div>
    )
}

export default Cssstyle