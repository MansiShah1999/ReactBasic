import React, { Component} from 'react'

const New = () => {
    //return(
    //    <div>
    //        <h1>Hey!This is Mansi</h1>
    //    </div>
    //)

    return(
        React.createElement('div',null,React.createElement('h1',null,'Hey Mansi'))
    )
}    
export default New