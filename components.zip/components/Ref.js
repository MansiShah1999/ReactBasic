import React,{Component} from 'react'

class Ref extends Component{

    constructor(props){
        super(props)

        this.newRef=React.createRef()
        this.cbRef= null
        this.SetcbRef=(element)=>{
            this.cbRef=element
        }
        
    }

    componentDidMount(){

        if(this.cbRef){
            this.cbRef.focus()
        }
        //this.newRef.current.focus()
        //console.log(this.newRef)
    }

    clickHandler=()=>{
        alert(this.newRef.current.value)
    }

    render(){
        return(
            <div>
                <input type="text" ref={this.newRef} />
                <input type="text" ref={this.SetcbRef} />
                <button onClick={this.clickHandler}>Click</button>
            </div>
            )
    }
}

export default Ref