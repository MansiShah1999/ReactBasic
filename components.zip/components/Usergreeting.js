import React,{ Component } from 'react'

class Usergreeting extends Component{

    constructor(props){
        super(props)

        this.state = {
            isLoggedIn : false
        }
    }
    render(){

        //short-circuit operator
        return this.state.isLoggedIn && <div>Welcome Mansi</div>

        //ternary operator
        /*
        return(
            this.state.isLoggedIn ?
            <div>Welcome Mansi</div>:
            <div>Welcome Guest</div>
        )
        */

        //element variables
        /*
        let message
        if(this.state.isLoggedIn){
            message=<div>Welcome Mansi</div>
        }else{
            message=<div>Welcome Guest</div>
        }

        return <div>{message}</div>
        */

        //if-else statement
        /*
        if(this.state.isLoggedIn){
        return(
            <div>
                Welcome Mansi
            </div>
        )
        }else{
            return(
                <div>
                    Welcome Guest
                </div>
            )
        }
        */
    }
}
export default Usergreeting