import React, { Component } from 'react'
{/*
class Welcome extends Component{
    render(){
        return <h1>{this.props.name} {this.props.surname}</h1>
    }
}
*/}
class Welcome extends Component{
    render(){
        const {name,surname} = this.props
        return (
            <h1>{name} {surname}</h1>
        )
    }
}
export default Welcome