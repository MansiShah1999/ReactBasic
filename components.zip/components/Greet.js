import React from 'react'
{/*
const Greet= (props) => {
    return (
    <div>
    <h1>Hello {props.name} {props.surname}</h1>
    {props.children}
    </div>
    )
}
*/}

const Greet= ({name,surname}) => {
    return (
    <div>
    <h1>Hello {name} {surname}</h1>
    {/*props.children*/}
    </div>
    )
}
//function Greet(){
//    return <h1>Hello Mansi</h1>
//}
export default Greet