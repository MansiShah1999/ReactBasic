import React,{Component} from 'react'
import {UserConsumer} from './userContext';
import UserContext from './userContext'

class ComponentF extends Component{

    static contextType=UserContext
    render(){
        {/*
        return(
            <UserConsumer>
                {
                    (username)=>{
                        return <div> Hello {username}</div>
                    }
                }
            </UserConsumer>
        )
            */}
            return(
                <div>
                    {this.context}
                </div>
            )
    }

}

export default ComponentF