import React from 'react'

function Column(){
    return(
        <React.Fragment>
            <td>Mansi</td>
            <td>Shah</td>
        </React.Fragment>
    )
}

export default Column