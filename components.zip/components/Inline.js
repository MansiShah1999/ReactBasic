import React from 'react'

const heading={
    fontSize:'72px',
    color:'red'
}
function Inline(){
    return(
    <div>
        <h1 style={heading}>Stylesheet</h1>
        
    </div>
    )
}

export default Inline