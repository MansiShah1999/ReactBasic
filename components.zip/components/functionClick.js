import React from 'react'

function Functionclick(){

    function clickhandler(){
        console.log('Button clicked')
    }

    return (
        <div>
        <button onClick={clickhandler}>Click me</button>
        </div>
    )
}

export default Functionclick