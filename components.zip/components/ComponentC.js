import React,{Component} from 'react'
import ComponentF from './ComponentF'

class ComponentC extends Component{

    render(){
        return(
            <div>
                <ComponentF />
            </div>
        )
    }

}

export default ComponentC